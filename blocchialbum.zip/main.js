$(document).ready(function() {
//QUERY string funziona per il GET ma non si può usare per tutti i metodi
//Con le password in GET chiunque la può leggere

//preparo la funzione per il template di handlebars
var source = $('#disco-template').html();
var template = Handlebars.compile(source);

//preparo le variabili per il template di handlebars
// var context = {
//     copertina: "Img/Ten_Summoner's_Tales.jpg",
//     titolo: "New Jersey",
//     artista: "Bon Jovi",
//     anno: "1988" };
// var html = template(context);
//
// //appendo l'html compilato con le variabili
// $('#dischi').append(html);

// chiamata ajax per recuperare i dicshi da visualizzare
$.ajax({
    'url': 'https://flynn.boolean.careers/exercises/api/array/music',
    'method': 'get',
    'success': function(data) {
        //recupero l'array che contiene tutti i dischi
        var dischi = data.response;
        console.log(data.response);
        console.log(dischi);
        //ciclo tutti i dischi
        for (var i = 0; i < dischi.length; i++) {
            //per ogni disco recupero le varie informazione /artista, disco img di copertina ecc)

            var disco = dischi[i];
            console.log(disco);
            var img_copertina = disco.poster;
            var album = disco.title;
            var artista_album = disco.author;
            var anno_uscita = disco.year;
            //creo le variabili di handlebars


            var context = {
                copertina: img_copertina,
                titolo: album,
                artista: artista_album,
                anno: anno_uscita,
            };

            //versione semplificata
            // 'success': function(data) {
            //     //recupero l'array che contiene tutti i dischi
            //     var dischi = data.response;
            //     console.log(data.response);
            //     console.log(dischi);
            //     //ciclo tutti i dischi
            //     for (var i = 0; i < dischi.length; i++) {
            //         //per ogni disco recupero le varie informazione /artista, disco img di copertina ecc)
            //
            //         var disco = dischi[i];
            //         console.log(disco);
            //         //creo le variabili di handlebars
            //
            //
            //         var context = {
            //             copertina: disco.poster,
            //             titolo: disco.title,
            //             artista: disco.author,
            //             anno: disco.year,
            //         };

            //creo il template
            var html = template(context);

           // appendo l'html compilato con le variabili
           // lo appendo al container dei dischi
           $('#dischi').append(html);

        }
    },
    'error': function() {
        alert('errore');
    }
})



//https://flynn.boolean.careers/exercises/api/array/music
//https://bitbucket.org/booleancareers/ex-dischi-musicali-layout/src/master/
});
